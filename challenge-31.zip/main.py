def linear_search_product(product_list, target_product):
    found_products = []

    for product in product_list:
        if product == target_product:
            found_products.append(product)

    return found_products

# Example usage:
products = ["apple", "banana", "orange", "apple", "grape", "apple"]
target = "apple"

result = linear_search_product(products, target)

if result:
    print(f"Found {target} in the list:")
    print(result)
else:
    print(f"{target} not found in the list.")






